package day1training;

public class OperatorsExample {
	
	public static void main(String...a) {
		
		//int value = 8;
		//int value1 = 2;
		//int val =(int)value;
		System.out.println(8 << 2);
		System.out.println(8 >>> 2);
	}

}
