package day1training;

public class DatatypesAndScopeofVariables {
	//static initializer block
	{
		//code which is required before execution of other code/methods
		int i= 20;
		System.out.println(i);
	}
	
	//default constructor
	//which is added by JVM
	public static void main(String...a)
	{
		DatatypesAndScopeofVariables dsv = new DatatypesAndScopeofVariables();
	}
}
