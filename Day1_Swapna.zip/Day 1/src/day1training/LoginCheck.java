package day1training;

import java.util.Scanner;

public class LoginCheck {
	static String uname ;//= null;//String is a predefined class in java.lang package
	static String pwd;
	public static void main(String...a)
	{
		Scanner input = new Scanner(System.in);


		
		System.out.println("Enter the username");
		uname = input.next();
		System.out.println("Enter the Password");
		pwd =  input.next();
		
		System.out.println(uname.hashCode() + "\t"+ "trisys".hashCode());
		System.out.println(pwd.hashCode() + "\t"+ "java".hashCode());
		
		
		//if((uname.equals("trisys"))&&(pwd .equals("java")))
		//{
		
		int un = uname.compareToIgnoreCase("trisys");
		int pw = pwd.compareTo("java");
		
		if((un == 0)&&(pw == 0))
		{
			System.out.println("login successful");
		}
		else
		{
			System.out.println("Not valid credentials");
		}
		
	}

}
