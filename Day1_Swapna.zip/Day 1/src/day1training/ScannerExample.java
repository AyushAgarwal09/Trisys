package day1training;

import java.util.Scanner;

public class ScannerExample {
	
	public static void main(String...a)
	{
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter the value");
		int n = sc.nextInt();
		System.out.println("Entered value is : "+n);
		sc.close();
	}

}
