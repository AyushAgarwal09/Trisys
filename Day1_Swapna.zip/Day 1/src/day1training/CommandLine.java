package day1training;

/**
 * 
 * @author 171470
 */

/**
 * This class is used to understand passing of command line arguments using eclipse
 */
public class CommandLine {

	public static void main(String...a)
	{
		System.out.println("Addition of two integers passed using command line");
		
		int val1 = Integer.parseInt(a[0]);
		int val2 = Integer.parseInt(a[1]);
		
		System.out.println("addition is:"+(val1 + val2));
		
	}
}
